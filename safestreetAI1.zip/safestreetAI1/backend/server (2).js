// server.js

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Home Route
app.get("/", (req, res) => {
    res.send("SOS Emergency Backend Server Running");
});

// SOS Alert Route
app.post("/send-sos", (req, res) => {

    const { username, location, emergency } = req.body;

    console.log("🚨 SOS ALERT RECEIVED");
    console.log("User:", username);
    console.log("Location:", location);
    console.log("Emergency Type:", emergency);

    res.status(200).json({
        success: true,
        message: "SOS Alert Sent Successfully",
        data: {
            username,
            location,
            emergency
        }
    });
});

// Emergency Service Notification Route
app.post("/notify-service", (req, res) => {

    const { serviceName } = req.body;

    console.log(`📢 ${serviceName} notified`);

    res.status(200).json({
        success: true,
        message: `${serviceName} notified successfully`
    });
});

// Disaster Notification Route
app.get("/disaster-alerts", (req, res) => {

    const alerts = [
        {
            id: 1,
            type: "Flood Warning",
            message: "Heavy rainfall expected in low-lying areas."
        },
        {
            id: 2,
            type: "Cyclone Alert",
            message: "Cyclone intensity increasing near coastal regions."
        },
        {
            id: 3,
            type: "Wildfire Alert",
            message: "Extreme temperatures may cause wildfires."
        }
    ];

    res.status(200).json(alerts);
});

// Start Server
app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
});