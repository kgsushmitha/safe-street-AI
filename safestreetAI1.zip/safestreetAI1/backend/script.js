document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('reportForm');
    const messageDiv = document.getElementById('message');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Gather data from the form
        const formData = {
            title: form.title.value,
            description: form.description.value,
            author: form.author.value,
            date: new Date().toISOString()
        };

        try {
            // Send data to backend
            const response = await fetch('/api/reports', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (response.ok) {
                messageDiv.style.color = 'green';
                messageDiv.textContent = 'Report submitted successfully!';
                form.reset();
            } else {
                messageDiv.style.color = 'red';
                messageDiv.textContent = 'Error: ' + result.error;
            }
        } catch (error) {
            console.error('Error:', error);
            messageDiv.style.color = 'red';
            messageDiv.textContent = 'Failed to connect to server.';
        }
    });
});