const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static(__dirname)); // serves frontend files if any

// Data file (acts like mini database)
const DATA_FILE = path.join(__dirname, "data.json");

/* -----------------------------
   HOME ROUTE (FIX FOR "Cannot GET /")
------------------------------*/
app.get("/", (req, res) => {
    res.send("🚦 SafeStreet AI Backend Running Successfully");
});

/* -----------------------------
   GET ALL REPORTS
------------------------------*/
app.get("/api/reports", (req, res) => {
    fs.readFile(DATA_FILE, "utf8", (err, data) => {
        if (err) {
            return res.json([]);
        }
        res.json(JSON.parse(data || "[]"));
    });
});

/* -----------------------------
   ADD NEW REPORT
------------------------------*/
app.post("/api/reports", (req, res) => {
    const newReport = req.body;

    fs.readFile(DATA_FILE, "utf8", (err, data) => {
        let reports = [];

        if (!err && data) {
            reports = JSON.parse(data);
        }

        reports.push(newReport);

        fs.writeFile(DATA_FILE, JSON.stringify(reports, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ error: "Error saving data" });
            }

            res.json({
                message: "Report saved successfully",
                data: newReport
            });
        });
    });
});

/* -----------------------------
   SERVER START
------------------------------*/
app.get("/", (req, res) => {
    res.send("🚦 SafeStreet AI Backend Running Successfully");
});
app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
});